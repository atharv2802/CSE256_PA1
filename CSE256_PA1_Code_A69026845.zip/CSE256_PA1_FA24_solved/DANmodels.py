import torch
from torch import nn
import torch.nn.functional as F
from torch.utils.data import Dataset
from sentiment_data import read_sentiment_examples

# Dataset class for handling sentiment analysis data for DAN
class SentimentDatasetDAN(Dataset):
    def __init__(self, infile, word_embeddings, max_seq_len=50):
        """
        Dataset class for the DAN model.
        
        Args:
            - infile (str): Path to the input file containing sentiment examples.
            - word_embeddings (WordEmbeddings): Pretrained word embeddings.
            - max_seq_len (int): Maximum sequence length for padding/truncating sentences.
        """
        self.examples = read_sentiment_examples(infile)
        self.word_embeddings = word_embeddings
        self.max_seq_len = max_seq_len
        self.sentences = [ex.words for ex in self.examples]
        self.labels = [ex.label for ex in self.examples]
        self.embeddings = self.vectorize_sentences(self.sentences)
        self.labels = torch.tensor(self.labels, dtype=torch.long)
    
    def vectorize_sentences(self, sentences):
        """
        Convert sentences into padded sequences of word indices.
        
        Args:
            - sentences (list of list of str): The input sentences (as tokenized words).
        
        Returns:
            - torch.Tensor: Tensor of word indices with padding.
        """
        indexed_sentences = []
        
        for sentence in sentences:
            indexed_sentence = [self.word_embeddings.indexer.get_index(word) for word in sentence]
            if len(indexed_sentence) < self.max_seq_len:
                indexed_sentence.extend([0] * (self.max_seq_len - len(indexed_sentence)))
            else:
                indexed_sentence = indexed_sentence[:self.max_seq_len]
            
            indexed_sentences.append(indexed_sentence)
        
        return torch.tensor(indexed_sentences, dtype=torch.long)
    
    def __len__(self):
        return len(self.examples)

    def __getitem__(self, idx):
        return self.embeddings[idx], self.labels[idx]


# Dataset class for handling sentiment analysis data for DAN using BPE
class SentimentDatasetDANBPE(Dataset):
    def __init__(self, infile, word_embeddings, bpe_tokenizer, max_seq_len=50):
        """
        Dataset class for the DAN model using BPE.
        
        Args:
            - infile (str): Path to the input file containing sentiment examples.
            - word_embeddings (WordEmbeddings): Pretrained word embeddings.
            - bpe_tokenizer: BPE tokenizer for converting sentences into subwords.
            - max_seq_len (int): Maximum sequence length for padding/truncating sentences.
        """
        self.examples = read_sentiment_examples(infile)
        self.word_embeddings = word_embeddings
        self.bpe_tokenizer = bpe_tokenizer
        self.max_seq_len = max_seq_len
        self.sentences = [ex.words for ex in self.examples]
        self.labels = [ex.label for ex in self.examples]
        self.embeddings = self.vectorize_sentences(self.sentences)
        self.labels = torch.tensor(self.labels, dtype=torch.long)

    def vectorize_sentences(self, sentences):
        """Convert sentences into padded sequences of word indices using BPE."""
        indexed_sentences = []
        
        for sentence in sentences:
            # Tokenize sentence using BPE
            bpe_tokens = self.bpe_tokenizer.tokenize(sentence)
            indexed_sentence = [self.word_embeddings.indexer.get_index(token) for token in bpe_tokens]
            if len(indexed_sentence) < self.max_seq_len:
                indexed_sentence.extend([0] * (self.max_seq_len - len(indexed_sentence)))
            else:
                indexed_sentence = indexed_sentence[:self.max_seq_len]
            
            indexed_sentences.append(indexed_sentence)
        
        return torch.tensor(indexed_sentences, dtype=torch.long)

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, idx):
        return self.embeddings[idx], self.labels[idx]


# Two-layer Deep Averaging Network (DAN) Model
class DAN2Layer(nn.Module):
    def __init__(self, word_embeddings, hidden_size=128, output_size=2, frozen=True):
        """
        Args:
            - word_embeddings (WordEmbeddings): Pretrained word embeddings.
            - hidden_size (int): Size of the hidden layer.
            - output_size (int): Number of output classes (default: 2 for sentiment classification).
            - frozen (bool): Whether to freeze the embedding layer during training.
        """
        super(DAN2Layer, self).__init__()
        
        self.embedding = word_embeddings.get_initialized_embedding_layer(frozen=frozen)
        embedding_dim = self.embedding.embedding_dim
        self.fc1 = nn.Linear(embedding_dim, hidden_size)
        self.fc2 = nn.Linear(hidden_size, output_size)
        self.log_softmax = nn.LogSoftmax(dim=1)

    def forward(self, x):
        embedded = self.embedding(x)
        averaged = torch.mean(embedded, dim=1)
        hidden = F.relu(self.fc1(averaged))
        output = self.fc2(hidden)
        return self.log_softmax(output)


# Three-layer Deep Averaging Network (DAN) Model
class DAN3Layer(nn.Module):
    def __init__(self, word_embeddings, hidden_size=128, output_size=2, frozen=True):
        """
        Args:
            - word_embeddings (WordEmbeddings): Pretrained word embeddings.
            - hidden_size (int): Size of the hidden layers.
            - output_size (int): Number of output classes (default: 2 for sentiment classification).
            - frozen (bool): Whether to freeze the embedding layer during training.
        """
        super(DAN3Layer, self).__init__()
        
        self.embedding = word_embeddings.get_initialized_embedding_layer(frozen=frozen)
        embedding_dim = self.embedding.embedding_dim
        self.fc1 = nn.Linear(embedding_dim, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, output_size)
        self.log_softmax = nn.LogSoftmax(dim=1)

    def forward(self, x):
        embedded = self.embedding(x)
        averaged = torch.mean(embedded, dim=1)
        hidden = F.relu(self.fc1(averaged))
        hidden = F.relu(self.fc2(hidden))
        output = self.fc3(hidden)
        return self.log_softmax(output)