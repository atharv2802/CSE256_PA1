import collections

class BPETokenizer:
    def __init__(self, target_vocab_size):
        self.bpe_codes = {}
        self.vocab = {}
        self.target_vocab_size = target_vocab_size

    def train_from_file(self, file_path, target_vocab_size):
        """Train the BPE tokenizer from a text file."""
        with open(file_path, 'r', encoding='utf-8') as f:
            text = f.read()

        # Initialize vocabulary with single characters
        words = text.split()
        self.vocab = collections.defaultdict(int)
        for word in words:
            word = ' '.join(list(word)) + ' </w>'
            self.vocab[word] += 1

        # Perform BPE merging until the target vocabulary size is reached
        while len(self.bpe_codes) < target_vocab_size:
            pairs = collections.defaultdict(int)

            for word, freq in self.vocab.items():
                symbols = word.split()
                for j in range(len(symbols) - 1):
                    pair = (symbols[j], symbols[j + 1])
                    pairs[pair] += freq

            if not pairs:
                break

            # Find the most frequent pair
            best_pair = max(pairs, key=pairs.get)

            # Merge the best pair in the vocabulary
            new_word = best_pair[0] + best_pair[1]
            self.vocab[new_word] = self.vocab.pop(best_pair[0]) + self.vocab.pop(best_pair[1])

            # Update BPE codes
            self.bpe_codes[best_pair] = len(self.bpe_codes)

    def encode(self, word):
        """Encode a word using BPE."""
        word = ' '.join(list(word)) + ' </w>'
        while True:
            pairs = [(word[i:i + 2], i) for i in range(len(word) - 1)]
            bigram = max(pairs, key=lambda pair: self.bpe_codes.get(pair[0], -1), default=None)
            if bigram is None or self.bpe_codes.get(bigram[0], -1) == -1:
                break
            word = word[:bigram[1]] + bigram[0] + word[bigram[1] + 2:]
        return word.strip().split()

    def decode(self, tokens):
        """Decode a list of tokens back to the original word."""
        return ''.join(tokens).replace(' </w>', '')

    def tokenize(self, text):
        """Tokenize a given text into BPE tokens."""
        words = text.split()
        return [self.encode(word) for word in words]
