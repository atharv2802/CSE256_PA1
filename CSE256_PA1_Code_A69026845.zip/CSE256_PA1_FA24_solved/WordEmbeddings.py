import torch
import torch.nn as nn
import numpy as np

class Indexer:
    def __init__(self):
        """
        Initialize the Indexer which stores word-to-index mappings.
        It also contains two special tokens: PAD (index 0) and UNK (index 1).
        """
        self.word_to_idx = {"<PAD>": 0, "<UNK>": 1}
        self.idx_to_word = ["<PAD>", "<UNK>"]
    
    def add_word(self, word):
        """
        Add a word to the indexer if it's not already present.
        
        Args:
            - word (str): The word to be added.
        
        Returns:
            - int: The index of the word.
        """
        if word not in self.word_to_idx:
            self.word_to_idx[word] = len(self.idx_to_word)
            self.idx_to_word.append(word)
        return self.word_to_idx[word]
    
    def get_index(self, word):
        """
        Get the index of a word. If the word is not found, return the index for <UNK>.
        
        Args:
            - word (str): The word to lookup.
        
        Returns:
            - int: The index of the word or the index of <UNK> if not found.
        """
        return self.word_to_idx.get(word, self.word_to_idx["<UNK>"])

    def get_word(self, index):
        """
        Get the word corresponding to an index.
        
        Args:
            - index (int): The index to lookup.
        
        Returns:
            - str: The word corresponding to the index.
        """
        if index < len(self.idx_to_word):
            return self.idx_to_word[index]
        return "<UNK>"

class WordEmbeddings:
    def __init__(self, embeddings_file=None, embedding_dim=300, random_init=False):
        """
        Initialize WordEmbeddings class by loading pretrained word vectors from a file or using random initialization.
        
        Args:
            - embeddings_file (str): Path to the pretrained embeddings file (only used if random_init is False).
            - embedding_dim (int): Dimension of the word embeddings (used for random initialization).
            - random_init (bool): Whether to use random initialization for embeddings.
        """
        self.indexer = Indexer()  # Initialize the indexer with PAD and UNK
        self.embedding_dim = embedding_dim
        
        if random_init:
            self.embeddings_matrix = self.initialize_random_embeddings()
        else:
            # Load the pretrained embeddings
            self.embeddings_matrix = self.load_embeddings(embeddings_file)
        
    def initialize_random_embeddings(self):
        """
        Initialize embeddings randomly with dimensions set to embedding_dim.
        
        Returns:
            - torch.Tensor: The embeddings matrix where each row is a random vector.
        """
        # Initialize embeddings for PAD and UNK
        embeddings_list = [np.zeros(self.embedding_dim), np.random.randn(self.embedding_dim)]  # PAD and UNK embeddings
        return torch.tensor(embeddings_list, dtype=torch.float32)

    def load_embeddings(self, embeddings_file):
        """
        Load pretrained word embeddings from a file.
        
        Args:
            - embeddings_file (str): Path to the embeddings file.
        
        Returns:
            - torch.Tensor: The embeddings matrix where each row is a word vector.
        """
        embeddings_list = [np.zeros(self.embedding_dim), np.random.randn(self.embedding_dim)]  # PAD and UNK embeddings
        with open(embeddings_file, 'r') as f:
            for line in f:
                split_line = line.split()
                word = split_line[0]
                vector = np.array([float(val) for val in split_line[1:]])
                
                # Add the word to the indexer and append the embedding vector
                self.indexer.add_word(word)
                embeddings_list.append(vector)
        
        # Convert the embeddings list to a NumPy array and then to a torch.Tensor
        embeddings_matrix = np.array(embeddings_list)
        return torch.tensor(embeddings_matrix, dtype=torch.float32)
    
    def get_initialized_embedding_layer(self, frozen=True):
        """
        Get a torch.nn.Embedding layer initialized with the pretrained embeddings.
        
        Args:
            - frozen (bool): If True, the embeddings will not be updated during training.
        
        Returns:
            - torch.nn.Embedding: The embedding layer initialized with the pretrained embeddings.
        """
        num_embeddings, embedding_dim = self.embeddings_matrix.shape
        embedding_layer = nn.Embedding(num_embeddings, embedding_dim)
        embedding_layer.weight = nn.Parameter(self.embeddings_matrix, requires_grad=not frozen)
        return embedding_layer
    
    def initialize_bpe_embeddings(self, num_tokens):
        """
        Initialize embeddings for BPE tokens.
        
        Args:
            - num_tokens (int): The number of tokens for which to create random embeddings.
        
        Returns:
            - torch.Tensor: Randomly initialized embeddings for BPE tokens.
        """
        # Initialize random embeddings for BPE tokens
        embeddings_matrix = np.random.randn(num_tokens, self.embedding_dim).astype(np.float32)
        return torch.tensor(embeddings_matrix, dtype=torch.float32)