DAN and BPE Execution:

This README provides instructions on how to execute the DAN (Deep Averaging Network) and BPE (Byte Pair Encoding) models, including the available command-line arguments and usage examples.

Overview:

The project includes the following models:

BOW (Bag of Words): A baseline model that utilizes a simple representation of the input data.
DAN (Deep Averaging Network): A neural network model that averages word embeddings to produce a single input representation.
DAN-BPE: An extension of the DAN model that incorporates Byte Pair Encoding for sub-word tokenization.


Command-Line Arguments:
The following command-line arguments are available for model execution:

--model: Specifies the model type to train. Acceptable values are BOW, DAN, and DAN-BPE (required).
--use_pretrained: Indicates whether to use pretrained embeddings. Acceptable values are Yes or No (default: Yes).
--embedding_file: Path to the embedding file. Default is data/glove.6B.300d-relativized.txt.
--hidden_size: Size of the hidden layer for DAN models. Default is 100.
--vocab_size: Target vocabulary size for BPE. Required if the model is DAN-BPE. Acceptable values are 500, 1000, 2000, 5000, 8000, 10000.

Usage Examples:

1. Run BOW Model
python main.py --model BOW 
This command trains the BOW model.

2. Run DAN Model with Random Initialization
python main.py --model DAN --use_pretrained No 
This command trains the DAN model with randomly initialized embeddings.

3. Run DAN Model with Default
python main.py --model DAN  
This command trains the DAN model with default.
use_pretrained: Yes
embedding_file: data/glove.6B.300d-relativized.txt
hidden_size: 100


3. Run DAN Model with another config
python main.py --model DAN --use_pretrained Yes --embedding_file data/glove.6B.50d-relativized.txt
This command trains the DAN model with default.
use_pretrained: Yes
embedding_file: data/glove.6B.300d-relativized.txt
hidden_size: 100/200

3. Run DAN-BPE Model with Specified Vocabulary Size
python main.py --model DAN-BPE --use_pretrained No --vocab_size 2000 
This command trains the DAN-BPE model using random initialized embeddings with a vocabulary size of 2000.


Conclusion
This README provides a comprehensive overview of how to run the DAN and BPE models, including the command-line arguments and usage examples. Ensure that you modify the arguments based on your specific needs when executing the models.

For any further questions or issues, please refer to the documentation or contact the project maintainers.

abiradar@ucsd.edu