import torch
from torch import nn
import torch.nn.functional as F
from sklearn.feature_extraction.text import CountVectorizer
from sentiment_data import read_sentiment_examples
from torch.utils.data import Dataset, DataLoader
import time
import argparse
import matplotlib.pyplot as plt
from BOWmodels import SentimentDatasetBOW, NN2BOW, NN3BOW
from DANmodels import SentimentDatasetDAN, SentimentDatasetDANBPE, DAN2Layer, DAN3Layer
from WordEmbeddings import WordEmbeddings
from BPE import BPETokenizer



# Training function
def train_epoch(data_loader, model, loss_fn, optimizer, is_dan=False):
    size = len(data_loader.dataset)
    num_batches = len(data_loader)
    model.train()
    train_loss, correct = 0, 0
    for batch, (X, y) in enumerate(data_loader):
        X = X.float()

        # Override X to long if training the DAN model
        if is_dan:
            X = X.long()  # Convert inputs to LongTensor for the DAN model

        # Compute prediction error
        pred = model(X)
        loss = loss_fn(pred, y)
        train_loss += loss.item()
        correct += (pred.argmax(1) == y).type(torch.float).sum().item()

        # Backpropagation
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    average_train_loss = train_loss / num_batches
    accuracy = correct / size
    return accuracy, average_train_loss


# Evaluation function
def eval_epoch(data_loader, model, loss_fn, optimizer, is_dan=False):
    size = len(data_loader.dataset)
    num_batches = len(data_loader)
    model.eval()
    eval_loss = 0
    correct = 0
    for batch, (X, y) in enumerate(data_loader):
        X = X.float()

        # Override X to long if training the DAN model
        if is_dan:
            X = X.long()  # Convert inputs to LongTensor for the DAN model

        # Compute prediction error
        pred = model(X)
        loss = loss_fn(pred, y)
        eval_loss += loss.item()
        correct += (pred.argmax(1) == y).type(torch.float).sum().item()

    average_eval_loss = eval_loss / num_batches
    accuracy = correct / size
    return accuracy, average_eval_loss


# Experiment function to run training and evaluation for multiple epochs
def experiment(model, train_loader, test_loader, is_dan=False):
    loss_fn = nn.NLLLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.0001)

    all_train_accuracy = []
    all_test_accuracy = []
    for epoch in range(100):
        train_accuracy, train_loss = train_epoch(train_loader, model, loss_fn, optimizer, is_dan)
        all_train_accuracy.append(train_accuracy)

        test_accuracy, test_loss = eval_epoch(test_loader, model, loss_fn, optimizer, is_dan)
        all_test_accuracy.append(test_accuracy)

        if epoch % 10 == 9:
            print(f'Epoch #{epoch + 1}: train accuracy {train_accuracy:.3f}, dev accuracy {test_accuracy:.3f}')
    
    return all_train_accuracy, all_test_accuracy


def main():
    # Set up argument parser
    parser = argparse.ArgumentParser(description='Run model training based on specified model type')
    parser.add_argument('--model', type=str, required=True, help='Model type to train (e.g., BOW, DAN)')
    parser.add_argument('--use_pretrained', type=str, choices=['Yes', 'No'], default='Yes',
                        help='Use pretrained embeddings (Yes/No)')
    parser.add_argument('--embedding_file', type=str, default='data/glove.6B.300d-relativized.txt',
                        help='Path to the embedding file')
    parser.add_argument('--hidden_size', type=int, default=100,
                        help='Size of the hidden layer for DAN models')
    parser.add_argument('--vocab_size', type=int, choices=[500, 1000, 2000, 5000, 8000, 10000], required='DAN-BPE' in args.model,
                        help='Target vocabulary size for BPE')

    # Parse the command-line arguments
    args = parser.parse_args()

    # Create a base name for the output files based on arguments
    base_filename = f"{args.model}_pretrained_{args.use_pretrained}_hidden_{args.hidden_size}"

    # Determine embedding dimensions based on the specified embedding file
    if args.embedding_file == 'data/glove.6B.300d-relativized.txt':
        embedding_dim = 300
    elif args.embedding_file == 'data/glove.6B.50d-relativized.txt':
        embedding_dim = 50
    else:
        raise ValueError("Invalid embedding file specified.")

    # Check if the model type is "BOW"
    if args.model == "BOW":
        # Load dataset
        start_time = time.time()

        train_data = SentimentDatasetBOW("data/train.txt")
        dev_data = SentimentDatasetBOW("data/dev.txt")
        train_loader = DataLoader(train_data, batch_size=16, shuffle=True)
        test_loader = DataLoader(dev_data, batch_size=16, shuffle=False)

        end_time = time.time()
        elapsed_time = end_time - start_time
        print(f"Data loaded in : {elapsed_time} seconds")

        # Train and evaluate NN2
        start_time = time.time()
        print('\n2 layers:')
        nn2_train_accuracy, nn2_test_accuracy = experiment(NN2BOW(input_size=512, hidden_size=100), train_loader, test_loader)

        # Train and evaluate NN3
        print('\n3 layers:')
        nn3_train_accuracy, nn3_test_accuracy = experiment(NN3BOW(input_size=512, hidden_size=100), train_loader, test_loader)

        # Plot the training accuracy for BOW
        plt.figure(figsize=(8, 6))
        plt.plot(nn2_train_accuracy, label='2 layers (BOW)')
        plt.plot(nn3_train_accuracy, label='3 layers (BOW)')
        plt.xlabel('Epochs')
        plt.ylabel('Training Accuracy')
        plt.title('Training Accuracy for BOW 2 and 3 Layer Networks')
        plt.legend()
        plt.grid()

        # Save the training accuracy figure
        training_accuracy_file = 'bow_train_accuracy.png'
        plt.savefig(training_accuracy_file)
        print(f"\n\nTraining accuracy plot saved as {training_accuracy_file}")

        # Plot the testing accuracy for BOW
        plt.figure(figsize=(8, 6))
        plt.plot(nn2_test_accuracy, label='2 layers (BOW)')
        plt.plot(nn3_test_accuracy, label='3 layers (BOW)')
        plt.xlabel('Epochs')
        plt.ylabel('Dev Accuracy')
        plt.title('Dev Accuracy for BOW 2 and 3 Layer Networks')
        plt.legend()
        plt.grid()

        # Save the testing accuracy figure
        testing_accuracy_file = 'bow_dev_accuracy.png'
        plt.savefig(testing_accuracy_file)
        print(f"Dev accuracy plot saved as {testing_accuracy_file}\n\n")

    elif args.model == "DAN":
        # Load dataset
        start_time = time.time()

        # Initialize word embeddings based on the command-line argument
        use_pretrained = args.use_pretrained == 'Yes'
        word_embeddings = WordEmbeddings(
            embeddings_file=args.embedding_file,
            embedding_dim=embedding_dim,
            random_init=(not use_pretrained)
        )

        train_data = SentimentDatasetDAN("data/train.txt", word_embeddings)
        dev_data = SentimentDatasetDAN("data/dev.txt", word_embeddings)
        train_loader = DataLoader(train_data, batch_size=16, shuffle=True)
        test_loader = DataLoader(dev_data, batch_size=16, shuffle=False)

        end_time = time.time()
        elapsed_time = end_time - start_time
        print(f"Data loaded in : {elapsed_time} seconds")

        # Train and evaluate DAN2Layer
        print('\nTraining DAN with 2 layers:')
        dan2_model = DAN2Layer(word_embeddings, hidden_size=args.hidden_size)
        dan2_train_accuracy, dan2_test_accuracy = experiment(dan2_model, train_loader, test_loader, is_dan=True)

        # Train and evaluate DAN3Layer
        print('\nTraining DAN with 3 layers:')
        dan3_model = DAN3Layer(word_embeddings, hidden_size=args.hidden_size)
        dan3_train_accuracy, dan3_test_accuracy = experiment(dan3_model, train_loader, test_loader, is_dan=True)

        # Plot the training accuracy for DAN
        plt.figure(figsize=(8, 6))
        plt.plot(dan2_train_accuracy, label='2 layers (DAN)')
        plt.plot(dan3_train_accuracy, label='3 layers (DAN)')
        plt.xlabel('Epochs')
        plt.ylabel('Training Accuracy')
        plt.title('Training Accuracy for DAN 2 and 3 Layer Networks')
        plt.legend()
        plt.grid()

         # Save the training accuracy figure
        training_accuracy_file = f'{base_filename}_dan_train_accuracy.png'
        plt.savefig(training_accuracy_file)
        print(f"\n\nTraining accuracy plot saved as {training_accuracy_file}")

        # Plot the testing accuracy for DAN
        plt.figure(figsize=(8, 6))
        plt.plot(dan2_test_accuracy, label='2 layers (DAN)')
        plt.plot(dan3_test_accuracy, label='3 layers (DAN)')
        plt.xlabel('Epochs')
        plt.ylabel('Dev Accuracy')
        plt.title('Dev Accuracy for DAN 2 and 3 Layer Networks')
        plt.legend()
        plt.grid()

        # Save the testing accuracy figure
        testing_accuracy_file = f'{base_filename}_dan_dev_accuracy.png'
        plt.savefig(testing_accuracy_file)
        print(f"Dev accuracy plot saved as {testing_accuracy_file}\n\n")

    elif args.model == "DAN-BPE":
        base_filename2 = f"{args.model}_pretrained_{args.use_pretrained}_hidden_{args.hidden_size}_vocab_{args.vocab_size}"
        # Load dataset
        start_time = time.time()

        # Initialize BPE tokenizer with specified vocabulary size
        bpe_tokenizer = BPETokenizer(target_vocab_size=args.vocab_size)
        bpe_tokenizer.train_from_file('data/train.txt')

        # Load the sentiment dataset using the BPE tokenizer
        train_data = SentimentDatasetDANBPE("data/train.txt", bpe_tokenizer)
        dev_data = SentimentDatasetDANBPE("data/dev.txt", bpe_tokenizer)
        train_loader = DataLoader(train_data, batch_size=16, shuffle=True)
        test_loader = DataLoader(dev_data, batch_size=16, shuffle=False)

        end_time = time.time()
        elapsed_time = end_time - start_time
        print(f"Data loaded in : {elapsed_time} seconds")

        # Train and evaluate DAN2Layer with BPE
        print('\nTraining DAN with 2 layers (BPE):')
        dan2_model = DAN2Layer(embedding_dim=embedding_dim, hidden_size=args.hidden_size)
        dan2_train_accuracy, dan2_test_accuracy = experiment(dan2_model, train_loader, test_loader, is_dan=True)

        # Train and evaluate DAN3Layer with BPE
        print('\nTraining DAN with 3 layers (BPE):')
        dan3_model = DAN3Layer(embedding_dim=embedding_dim, hidden_size=args.hidden_size)
        dan3_train_accuracy, dan3_test_accuracy = experiment(dan3_model, train_loader, test_loader, is_dan=True)

        # Plot the training accuracy for DAN with BPE
        plt.figure(figsize=(8, 6))
        plt.plot(dan2_train_accuracy, label='2 layers (DAN-BPE)')
        plt.plot(dan3_train_accuracy, label='3 layers (DAN-BPE)')
        plt.xlabel('Epochs')
        plt.ylabel('Training Accuracy')
        plt.title('Training Accuracy for DAN BPE 2 and 3 Layer Networks')
        plt.legend()
        plt.grid()

        # Save the training accuracy figure
        training_accuracy_file = f'{base_filename2}_dan_bpe_train_accuracy.png'
        plt.savefig(training_accuracy_file)
        print(f"\n\nTraining accuracy plot saved as {training_accuracy_file}")

        # Plot the testing accuracy for DAN with BPE
        plt.figure(figsize=(8, 6))
        plt.plot(dan2_test_accuracy, label='2 layers (DAN-BPE)')
        plt.plot(dan3_test_accuracy, label='3 layers (DAN-BPE)')
        plt.xlabel('Epochs')
        plt.ylabel('Dev Accuracy')
        plt.title('Dev Accuracy for DAN BPE 2 and 3 Layer Networks')
        plt.legend()
        plt.grid()

        # Save the testing accuracy figure
        testing_accuracy_file = f'{base_filename2}_dan_bpe_dev_accuracy.png'
        plt.savefig(testing_accuracy_file)
        print(f"Dev accuracy plot saved as {testing_accuracy_file}\n\n")

if __name__ == "__main__":
    main()